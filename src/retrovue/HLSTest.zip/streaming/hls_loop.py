"""
HLS Looper for Retrovue.

Provides the ability to create live HLS streams that loop content forever.
"""

from __future__ import annotations
import pathlib
import subprocess
import time
import math
import os
from typing import Optional

# Cross-platform no-cache headers are handled at the FastAPI layer.
# This module focuses on producing segments and a rolling playlist.

class HLSLooper:
    """
    Minimal HLS writer that appends segments to a rolling index.m3u8 and
    loops a single source file forever. It maintains a persistent segment
    counter so MEDIA-SEQUENCE advances monotonically across restarts.
    """

    def __init__(self, channel_dir: pathlib.Path, segment_time_sec: int = 6, playlist_window: int = 10, transcode: bool = False):
        self.channel_dir = pathlib.Path(channel_dir)
        self.segment_time_sec = int(segment_time_sec)
        self.playlist_window = int(playlist_window)
        self.transcode = transcode
        self.state_file = self.channel_dir / "start_number.txt"
        self.proc: Optional[subprocess.Popen] = None

        self.channel_dir.mkdir(parents=True, exist_ok=True)

    # ---- Segment numbering state ----
    def _read_start_number(self) -> int:
        if self.state_file.exists():
            try:
                return int(self.state_file.read_text().strip())
            except Exception:
                return 0
        return 0

    def _write_start_number(self, n: int) -> None:
        self.state_file.write_text(str(n), encoding="utf-8")

    # ---- FFmpeg process ----
    def _spawn_ffmpeg(self, src_path: pathlib.Path, start_number: int) -> subprocess.Popen:
        """
        Spawn ffmpeg to transmux the source into rolling HLS.
        Use append_list + discont_start so every fresh invocation starts a new discontinuity.
        """
        # Use forward slashes for FFmpeg paths to avoid Windows path issues
        seg_pat = str(self.channel_dir / "seg_%09d.ts").replace("\\", "/")
        m3u8 = str(self.channel_dir / "index.m3u8").replace("\\", "/")

        # Base command with common parameters
        cmd = [
            "ffmpeg",
            "-hide_banner",
            "-loglevel", "warning",
            "-re",                     # read at real-time
            "-i", str(src_path),
        ]

        if self.transcode:
            # Transcode path: H.264/AAC with keyframe-aligned segmenting
            keyframe_interval = self.segment_time_sec * 10
            cmd.extend([
                "-c:v", "libx264",
                "-preset", "veryfast",
                "-tune", "zerolatency",
                "-profile:v", "main",
                "-pix_fmt", "yuv420p",
                "-r", "30",  # Force 30fps for consistent timing
                "-g", str(keyframe_interval),
                "-keyint_min", str(keyframe_interval),
                "-sc_threshold", "0",
                f"-force_key_frames", f"expr:gte(t,n_forced*{self.segment_time_sec})",
                "-c:a", "aac",
                "-b:a", "192k",
                "-ac", "2",
                "-avoid_negative_ts", "make_zero",
                "-fflags", "+genpts",
                "-x264opts", f"keyint={keyframe_interval}:min-keyint={keyframe_interval}:scenecut=0",
                "-segment_time_metadata", "1",
                "-break_non_keyframes", "1",
            ])
        else:
            # Copy path: existing behavior
            cmd.extend([
                "-c:v", "copy",
                "-c:a", "copy",
            ])

        # Common HLS parameters
        cmd.extend([
            "-f", "hls",
            "-hls_time", str(self.segment_time_sec),
            "-hls_list_size", str(self.playlist_window),
            # Use sliding live window instead of growing event playlist
            "-hls_flags", "delete_segments+program_date_time+omit_endlist+independent_segments",
            "-hls_segment_filename", seg_pat,
            "-start_number", str(start_number),
            "-hls_segment_type", "mpegts",
            "-hls_allow_cache", "0",
            "-segment_time_metadata", "1",
            "-break_non_keyframes", "1",
            m3u8,
        ])

        return subprocess.Popen(cmd)

    def start_supervised_looping(self, src_path: pathlib.Path, duration_ms: Optional[int]) -> None:
        """
        Run ffmpeg repeatedly for one episode duration, then restart it to insert a discontinuity.
        If duration_ms is unknown, estimate by watching segment outputs (fallback).
        This call returns immediately; ffmpeg keeps running. You typically keep the process alive
        in your main CLI until the HTTP server exits.
        """
        start_number = self._read_start_number()

        # Launch once immediately
        self.proc = self._spawn_ffmpeg(src_path, start_number)

        # Supervisory loop: periodically bump start_number and restart ffmpeg at each episode wrap
        # to force a discontinuity on repeat.
        # We run this in the background-like style (callers normally won't await here).
        # For MVP, keep it simple: estimate repeats based on duration if provided.
        if duration_ms is None or duration_ms <= 0:
            # No duration known: do nothing; ffmpeg will just keep going.
            return

        # Supervisory loop in a lightweight "tick" style.
        # NOTE: Callers can simply let this run; the FastAPI server will block the main thread.
        def _tick():
            nonlocal start_number
            # How many segments do we expect per episode?
            segs_per_episode = max(1, math.ceil((duration_ms / 1000) / self.segment_time_sec))
            # Sleep for the episode duration (rounded)
            time.sleep(max(1, int(duration_ms / 1000)))
            # On wake: stop current ffmpeg, advance start number, relaunch to insert discontinuity
            try:
                if self.proc and self.proc.poll() is None:
                    self.proc.terminate()
                    try:
                        self.proc.wait(timeout=5)
                    except Exception:
                        self.proc.kill()
                # Wait a moment for file handles to be released
                time.sleep(1)
                start_number += segs_per_episode
                self._write_start_number(start_number)
                self.proc = self._spawn_ffmpeg(src_path, start_number)
            except Exception as e:
                # If restart fails, try again next cycle
                print(f"Warning: Failed to restart ffmpeg: {e}")

        # Fire-and-forget background ticks forever
        # (In a proper service, you'd run this in a thread; for a CLI MVP, simple loop is fine.)
        while True:
            _tick()

    def stop(self) -> None:
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=5)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
