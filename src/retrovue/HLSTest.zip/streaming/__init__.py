"""
Streaming module for Retrovue.

Provides HLS streaming capabilities for live playback.
"""
