"""
Play command for Retrovue CLI.

Provides the ability to play episodes as live HLS streams.
"""

from __future__ import annotations
import pathlib
import subprocess
import signal
import sys
import time
import typer
from typing import Optional

from retrovue.streaming.hls_loop import HLSLooper
from retrovue.web.server import run_server
from .uow import session
from ..app.library_service import LibraryService
from ..domain.entities import ProviderRef, EntityType

def resolve_asset_by_series_season_episode(series: str, season: int, episode: int) -> dict | None:
    """
    Resolve an asset by series, season, and episode number.
    
    Args:
        series: Series title
        season: Season number
        episode: Episode number
        
    Returns:
        Dict with asset information: { "uuid": str, "uri": str, "duration_ms": int }
        or None if not found
    """
    with session() as db:
        library_service = LibraryService(db)
        
        try:
            # Get all episodes for the series
            assets = library_service.list_episodes_by_series(series)
            
            if not assets:
                return None
            
            # Find the specific episode by season and episode number
            for asset in assets:
                # Get provider reference for metadata
                provider_ref = db.query(ProviderRef).filter(
                    ProviderRef.asset_id == asset.id,
                    ProviderRef.entity_type == EntityType.ASSET
                ).first()
                
                if provider_ref and provider_ref.raw:
                    raw = provider_ref.raw
                    asset_season = raw.get('parentIndex')
                    asset_episode = raw.get('index')
                    
                    # Convert to integers for comparison
                    try:
                        asset_season = int(asset_season) if asset_season else 0
                        asset_episode = int(asset_episode) if asset_episode else 0
                    except (ValueError, TypeError):
                        continue
                    
                    # Check if this matches our target season/episode
                    if asset_season == season and asset_episode == episode:
                        return {
                            "uuid": str(asset.uuid),
                            "uri": asset.uri,
                            "duration_ms": asset.duration_ms or 0
                        }
            
            return None
            
        except Exception as e:
            # Log error but don't raise - let caller handle
            print(f"Error resolving asset: {e}")
            return None

def play(
    series: str = typer.Argument(..., help="Series title, e.g. 'Cheers'"),
    season: int = typer.Option(..., "--season", "-s", help="Season number"),
    episode: int = typer.Option(..., "--episode", "-e", help="Episode number"),
    out_dir: pathlib.Path = typer.Option(pathlib.Path("./out/ch1"), "--out-dir", help="Output dir for HLS"),
    port: int = typer.Option(8000, "--port", "-p", help="HTTP port to serve playlist/segments"),
    seg_time: int = typer.Option(6, "--seg-time", help="HLS segment duration in seconds"),
    window: int = typer.Option(10, "--window", help="Number of segments visible in the rolling playlist"),
    transcode: bool = typer.Option(False, "--transcode", help="Transcode to H.264/AAC for smoother, broadly compatible HLS"),
):
    """
    Resolve an episode from the content library and expose it as a perpetual live HLS channel.
    """
    # 1) Resolve asset via your content library
    asset = resolve_asset_by_series_season_episode(series, season, episode)
    if not asset:
        typer.echo(f"[error] Could not resolve asset for {series} S{season:02d}E{episode:02d}", err=True)
        raise typer.Exit(code=1)

    # Normalize path: handle 'file://R:\\...'
    uri = asset["uri"]
    if uri.startswith("file://"):
        # Strip scheme; pathlib can handle Windows paths once scheme removed
        src_path = pathlib.Path(uri.replace("file://", "", 1))
    else:
        src_path = pathlib.Path(uri)

    if not src_path.exists():
        typer.echo(f"[error] Source path does not exist: {src_path}", err=True)
        raise typer.Exit(code=2)

    out_dir.mkdir(parents=True, exist_ok=True)

    # 2) Start the HLS looper
    looper = HLSLooper(
        channel_dir=out_dir,
        segment_time_sec=seg_time,
        playlist_window=window,
        transcode=transcode,
    )

    # IMPORTANT: For the MVP we use a supervisory loop that
    # restarts ffmpeg at each "episode wrap" to insert a discontinuity.
    # (ffmpeg -stream_loop -1 would not emit a discontinuity at wrap.)
    
    # Start the HLS looper in a separate thread so it can run concurrently with the HTTP server
    import threading
    looper_thread = threading.Thread(target=lambda: looper.start_supervised_looping(src_path, asset.get("duration_ms")))
    looper_thread.daemon = True
    looper_thread.start()
    
    # Give the looper a moment to start generating segments
    time.sleep(2)
    
    try:
        # Run the HTTP server (blocking) to serve index.m3u8 / segments
        run_server(
            mount_path="/ch1",
            directory=str(out_dir),
            port=port,
        )
    except KeyboardInterrupt:
        typer.echo("\nShutting down...")
    finally:
        looper.stop()

if __name__ == "__main__":
    # This module should not be run directly
    # Use: python -m retrovue.cli.main play
    import sys
    print("Error: This module should not be run directly.")
    print("Use: python -m retrovue.cli.main play")
    sys.exit(1)
